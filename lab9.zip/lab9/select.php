<?php
include("db.php");

$sql = "SELECT * FROM users";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Users Data</title>
</head>
<body>

<h2>Users Details</h2>

<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Password</th>
        <th>Profile Picture</th>
        <th>Created At</th>
    </tr>

    <?php
    if(mysqli_num_rows($result) > 0)
    {
        while($row = mysqli_fetch_assoc($result))
        {
    ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['username']; ?></td>
        <td><?php echo $row['email']; ?></td>
        <td><?php echo $row['phone']; ?></td>
        <td><?php echo $row['password']; ?></td>
        <td>
            <img src="uploads/<?php echo $row['profile_pic']; ?>" width="50" height="50">
        </td>
        <td><?php echo $row['created_at']; ?></td>
    </tr>
    <?php
        }
    }
    else
    {
        echo "<tr><td colspan='7'>No Data Found</td></tr>";
    }
    ?>

</table>

</body>
</html>