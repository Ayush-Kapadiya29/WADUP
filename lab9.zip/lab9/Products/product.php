<!DOCTYPE html>
<html>
<head>
<title>Product Details</title>
</head>
<body>

<center>

<h2>Product Details</h2>

<form method="POST" enctype="multipart/form-data">

<label>Product Name</label><br>
<input type="text" name="product_name" required><br><br>

<label>Product Price</label><br>
<input type="number" name="product_price" required><br><br>

<label>Product Quantity</label><br>
<input type="number" name="product_qty" required><br><br>

<label>Product Type</label><br>

<select name="product_type" required>
    <option value="">Select Product Type</option>
    <option>Mobile</option>
    <option>Laptop</option>
    <option>Smart Watch</option>
    <option>Headphone</option>
    <option>Camera</option>
</select>

<br><br>

<label>Product Image</label><br>

<input type="file" name="product_image" required>

<br><br>

<input type="submit" name="submit" value="Submit">

</form>

</center>

<?php

include 'db.php';

if(isset($_POST['submit']))
{

$product_name=$_POST['product_name'];
$product_price=$_POST['product_price'];
$product_qty=$_POST['product_qty'];
$product_type=$_POST['product_type'];

$image_name=$_FILES['product_image']['name'];
$tmp=$_FILES['product_image']['tmp_name'];

move_uploaded_file($tmp,"uploads/".$image_name);

$sql="INSERT INTO products(product_name,product_price,product_qty,product_type,product_image)
VALUES('$product_name','$product_price','$product_qty','$product_type','$image_name')";

if(mysqli_query($conn,$sql))
{
    echo "<script>alert('Product Added Successfully');</script>";
}
else
{
    echo mysqli_error($conn);
}

}

?>

</body>
</html>