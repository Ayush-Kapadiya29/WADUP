<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body><center>

    <h2>Sign up</h2>
    
    <form method="POST" enctype="multipart/form-data">
        
        <div>
            <label for="username">Username:</label>
            <input type="text" name="username" required><br><br>
        

        
            <label for="email">Email:</label>
            <input type="email" name="email" required><br><br>
        

        
            <label for="phone">Phone Number:</label>
            <input type="tel" name="phone" required><br><br>
        

        
            <label for="password">Password:</label>
            <input type="password" name="password" required><br><br>
        

        
            <label for="confirm_password">Confirm Password:</label>
            <input type="password" name="confirm_password" required><br><br>
        

        
            <label for="profile">Profile:</label>
            <input type="file" id="profile" name="profile" accept="image/*" required><br><br>
        

        
            <button type="submit" name="submit">Sign Up</button>
        </div>
        
    </form></center>

    <?php
    include 'db.php';
    
    if (isset($_POST['submit'])) {
    
        $user = $_POST['username'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $pass = $_POST['password'];
        $con_pass = $_POST['confirm_password'];
    
        $image_name = $_FILES['profile']['name'];
        $tmp_name = $_FILES['profile']['tmp_name'];
    
        move_uploaded_file($tmp_name, "uploads/" . $image_name);
    
        if ($pass == $con_pass) {
    
            $sql = "INSERT INTO users(username, email, phone, password, profile_pic)
                    VALUES('$user','$email','$phone','$pass','$image_name')";
    
            if (mysqli_query($conn, $sql)) {
                echo "Signup Successful";
            } else {
                echo mysqli_error($conn);
            }
    
        } else {
            echo "Passwords do not match";
        }
    }
    ?>
</body>

</html>